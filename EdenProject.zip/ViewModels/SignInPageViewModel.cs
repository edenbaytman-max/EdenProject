﻿using EdenProject.Service;
using System.Windows.Input;

namespace EdenProject.ViewModels
{
    public class SignInPageViewModel : ViewModelBase
    {
        DBMokup _db;
        private bool _entryAsPassword;
        private string _userName;
        private string _password;
        private string _togglePasswordButtonText;
        private string _loginMessage;
        private bool _signInMessageVisible;
        private Color _signInColor;
        private bool _isSignInButtonEnabled; // Added this property

        public ICommand ShowPasswordCommand { get; }
        public ICommand SignInCommand { get; }

        public SignInPageViewModel()
        {
            _db = new DBMokup();
            EntryAsPassword = true;
            TogglePaswwordButtonText = "\ue8f5"; // Using eye icon code
            SignInMessageVisible = false;
            LoginMessage = string.Empty;

            ShowPasswordCommand = new Command(TogglePasswordVisibility);
            SignInCommand = new Command(Button_Clicked, CanSignIn);
        }

        // This property fixes your "Property Not Found" error
        public bool IsSignInButtonEnabled
        {
            get => _isSignInButtonEnabled;
            set { _isSignInButtonEnabled = value; OnPropertyChanged(); }
        }

        public Color SignInColor { get => _signInColor; set { _signInColor = value; OnPropertyChanged(); } }
        public bool SignInMessageVisible { get => _signInMessageVisible; set { _signInMessageVisible = value; OnPropertyChanged(); } }
        public string LoginMessage { get => _loginMessage; set { _loginMessage = value; OnPropertyChanged(); } }

        public string UserName
        {
            get => _userName;
            set
            {
                _userName = value;
                OnPropertyChanged();
                UpdateCommandStates();
            }
        }

        public string UserPassword
        {
            get => _password;
            set
            {
                _password = value;
                OnPropertyChanged();
                UpdateCommandStates();
            }
        }

        public bool EntryAsPassword { get => _entryAsPassword; set { _entryAsPassword = value; OnPropertyChanged(); } }
        public string TogglePaswwordButtonText { get => _togglePasswordButtonText; set { _togglePasswordButtonText = value; OnPropertyChanged(); } }

        private void UpdateCommandStates()
        {
            ((Command)SignInCommand).ChangeCanExecute();
            // This manually updates the property your XAML is looking for
            IsSignInButtonEnabled = CanSignIn();
        }

        private void TogglePasswordVisibility()
        {
            EntryAsPassword = !EntryAsPassword;
            TogglePaswwordButtonText = EntryAsPassword ? "\ue8f5" : "\ue8f4";
        }

        private void Button_Clicked()
        {
            SignInMessageVisible = true;
            if (_db.isExist(UserName, UserPassword))
            {
                LoginMessage = "התחברת בהצלחה!";
                SignInColor = Colors.Green;
            }
            else
            {
                LoginMessage = "שגיאת התחברות - נתונים שגויים";
                SignInColor = Colors.Red;
            }
        }

        private bool CanSignIn()
        {
            return !string.IsNullOrEmpty(UserName) && !string.IsNullOrEmpty(UserPassword);
        }
    }
}