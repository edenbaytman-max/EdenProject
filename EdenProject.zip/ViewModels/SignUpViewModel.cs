﻿using EdenProject.Models;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using EdenProject.Service;

namespace EdenProject.ViewModels
{
    public class SignUpViewModel : INotifyPropertyChanged
    {
        DBMokup _db = new DBMokup();
        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

        #region Private Fields
        private string _firstName;
        private string _lastName;
        private string _email;
        private string _password;
        private string _mobile;
        private bool _entryAsPassword;
        private string _passwordIconCode;
        #endregion

        #region Public Properties
        public string FirstName { get => _firstName; set { _firstName = value; OnPropertyChanged(); ((Command)SignUpCommand).ChangeCanExecute(); } }
        public string LastName { get => _lastName; set { _lastName = value; OnPropertyChanged(); ((Command)SignUpCommand).ChangeCanExecute(); } }
        public string UserEmail { get => _email; set { _email = value; OnPropertyChanged(); ((Command)SignUpCommand).ChangeCanExecute(); } }
        public string UserPassword { get => _password; set { _password = value; OnPropertyChanged(); ((Command)SignUpCommand).ChangeCanExecute(); } }
        public string Mobile { get => _mobile; set { _mobile = value; OnPropertyChanged(); ((Command)SignUpCommand).ChangeCanExecute(); } }

        public bool EntryAsPassword
        {
            get => _entryAsPassword;
            set { _entryAsPassword = value; OnPropertyChanged(); }
        }

        public string PasswordIconCode
        {
            get => _passwordIconCode;
            set { _passwordIconCode = value; OnPropertyChanged(); }
        }
        #endregion

        #region Commands
        public ICommand ShowPasswordCommand { get; }
        public ICommand SignUpCommand { get; }
        public ICommand SignInCommand { get; }
        #endregion

        public SignUpViewModel()
        {
            // Initial State
            EntryAsPassword = true;
            PasswordIconCode = "\ue8f5"; // Closed eye icon

            // Initialize Commands
            ShowPasswordCommand = new Command(TogglePasswordButton);
            SignUpCommand = new Command(SignUp, Validate);
            SignInCommand = new Command(NavigateToSignIn);
        }

        private void TogglePasswordButton()
        {
            EntryAsPassword = !EntryAsPassword;
            // Toggle between closed eye (\ue8f5) and open eye (\ue8f4)
            PasswordIconCode = EntryAsPassword ? "\ue8f5" : "\ue8f4";
        }

        private bool Validate()
        {
            // Returns true only if all fields have text
            return !string.IsNullOrWhiteSpace(FirstName) &&
                   !string.IsNullOrWhiteSpace(LastName) &&
                   !string.IsNullOrWhiteSpace(UserEmail) &&
                   !string.IsNullOrWhiteSpace(UserPassword) &&
                   !string.IsNullOrWhiteSpace(Mobile);
        }

        private async void SignUp()
        {
            // Create the user object from the entry fields
            var newUser = new User
            {
                UserEmail = this.UserEmail,
                UserPassword = this.UserPassword
            };

            // Save it to the mockup DB
            _db.AddUser(newUser);

            await Shell.Current.DisplayAlert("Success", "Account Created! You can now Sign In.", "OK");

            // Navigate to Sign In page
            await Shell.Current.GoToAsync("//SignInPage");
        }

        private async void NavigateToSignIn()
        {
            if (Shell.Current != null)
            {
                // Use "//" to switch to the SignInPage route
                await Shell.Current.GoToAsync("//SignInPage");
            }
            else
            {
                // Fallback if Shell is somehow null (useful for debugging)
                Application.Current.MainPage = new EdenProject.Views.SignInPage();
            }
        }
    }
}