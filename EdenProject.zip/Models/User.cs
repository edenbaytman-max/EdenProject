﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdenProject.Models
{
    internal class User
    {
        public string? UserEmail { get; set; }
        public string? UserPassword { get; set; }
    }
}
