
using EdenProject.Service;
using EdenProject.ViewModels;
using System.Diagnostics.Contracts;

namespace EdenProject.Views;

public partial class SignInPage : ContentPage
{
    
    
    public SignInPage()
	{
		InitializeComponent();

        BindingContext = new SignInPageViewModel();
	}

    
}