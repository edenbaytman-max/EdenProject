namespace EdenProject.Views;
using EdenProject.ViewModels; // Import your viewmodels namespace

public partial class SignUpPage : ContentPage
{
    public SignUpPage()
    {
        InitializeComponent();
        // Connect the Page to the ViewModel
        BindingContext = new SignUpViewModel();
    }
}