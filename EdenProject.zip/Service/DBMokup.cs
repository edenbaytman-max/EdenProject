﻿using EdenProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdenProject.Service
{
    internal class DBMokup
    {
        // 1. MUST BE STATIC: This way Sign-Up and Sign-In share the same list
        private static List<User> _users = new List<User>();

        public DBMokup()
        {
            if (_users.Count == 0) // Only add defaults the first time
            {
                _users.Add(new User { UserEmail = "a", UserPassword = "a" });
            }
        }

        public bool isExist(string uEmail, string uPass)
        {
            return _users.Any(u => u.UserEmail == uEmail && u.UserPassword == uPass);
        }

        // 2. YOU NEED THIS METHOD: So the SignUpViewModel can save users
        public void AddUser(User newUser)
        {
            _users.Add(newUser);
        }
    }
}