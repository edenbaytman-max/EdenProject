﻿using EdenProject.Views;

namespace EdenProject;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();

        // WRONG: MainPage = new Views.SignUpPage(); 
        // RIGHT: You must use AppShell to use Shell.Current
        MainPage = new AppShell();
    }
}